package com.example.simpgmaillogin
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.ImageView
import android.widget.Toast
class AddAccount: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_account)
        val logoImage = findViewById<ImageView>(R.id.logoImage)
        main()
    }
    public fun main() {
        val emailInput = this.findViewById<EditText>(R.id.emailInput)
        val passwordlInput = this.findViewById<EditText>(R.id.passwordInput)
        val saveaccountInButton = this.findViewById<Button>(R.id.saveaccountInButton)
        val showToast: (String, Int) -> Unit = { message, color ->
            val toastView = TextView(this).apply {
                text = message
                setTextColor(Color.RED)
                textSize = 35f
                setTypeface(null, Typeface.BOLD)
                setPadding(30, 8, 30, 18)
                background = GradientDrawable().apply {
                    setColor(color)
                    cornerRadius = 20f
                }
            }
            Toast(this).apply {
                duration = Toast.LENGTH_SHORT
                view = toastView
            }.show()
        }
    saveaccountInButton.setOnClickListener {
        val emailText = emailInput.text.toString().trim()
        val passwordText = passwordlInput.text.toString().trim()
        if (emailText.isEmpty()) {
            emailInput.setError("❗ Email is required")
        }
        else if (passwordText.isEmpty()) {
            passwordlInput.setError("! Password is required")
        }
        when {
            emailText.isEmpty() ->

                showToast("Please enter email", Color.WHITE)
            passwordText.isEmpty() ->
                showToast("Please enter password", Color.WHITE)
            else ->
                try {
                    showToast("Processing.", Color.WHITE)
                    /*val intent = Intent(this, AddAccount::class.java)
                    startActivity(intent)*/
                } catch (e: Exception) {
                    throw e
                    println(e.message)
                }
                finally {
                }
           }
        }
    }
}
